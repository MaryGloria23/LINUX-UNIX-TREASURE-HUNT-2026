========================================================
  DR. KIZZA'S PROJECT DIRECTORY
  Left in a hurry — 7 June 2026, 11:47pm
========================================================

If you are reading this, you are my research assistant.
I had to leave the lab unexpectedly. My analysis is
half-finished and I need you to find your way around
this project before my supervisor meeting tomorrow.

I have left clues for you along the way.
Follow them carefully. Do not panic.

Your first task: find out exactly where you are,
then look carefully at what is in this directory.
Not everything that exists is easy to see.

-- Dr. Kizza

P.S. The raw data is where everything begins.
     Start there.
