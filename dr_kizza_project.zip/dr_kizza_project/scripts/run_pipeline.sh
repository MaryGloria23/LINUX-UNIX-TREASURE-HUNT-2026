#!/bin/bash
# run_pipeline.sh
# Dr. Kizza's alignment pipeline script
# Status: INCOMPLETE - left in a hurry

REFERENCE="reference/Pfalciparum_3D7.fasta"
SAMPLES_DIR="raw_data"
RESULTS_DIR="results"

echo "Starting pipeline..."
echo "This script is incomplete. See logs/pipeline.log for what ran so far."

# TODO: complete this script
